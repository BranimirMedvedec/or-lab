import { Club } from "./Club"

export type Database = Club[]
