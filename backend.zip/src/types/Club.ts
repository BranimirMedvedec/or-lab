export type Club = {
	_id?: string
	"Naziv kluba": string
	"Godina osnutka": number
	Adresa: string
	"Telefon/fax": string
	"E-mail": string
	"Web mjesto": string
	"Ovlaštena osoba1": string
	OIB: string
	"Registarski broj": number
	"Datum unosa/izmjene": string
	"Član RSS": string
	Sportovi: string[]
}
